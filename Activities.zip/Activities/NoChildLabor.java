package com.example.suryamsrivastava.virtusaproject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class NoChildLabor extends Activity implements View.OnClickListener{

    ImageView cameraImage;
    static final int REQUEST_IMAGE_CAPTURE=1;

    Session session=null;
    ProgressDialog pDialog=null;
    Context context=null;
    EditText receip,sub,address,feedback;
    String rec, subject;
    StringBuffer textMessage;
    Bitmap photo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_no_child_labor);

        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        cameraImage=(ImageView)findViewById(R.id.cameraImageButtonForChildLabor);

        if(!hasCamera())
        {
            Toast.makeText(getApplicationContext(),"No Camera Found", Toast.LENGTH_LONG).show();

        }


        context=this;
        Button login=(Button)findViewById(R.id.child_complaint_submit);
        //receip=(EditText)findViewById(R.id.et_to);
        //sub=(EditText)findViewById(R.id.et_sub);
        address=(EditText)findViewById(R.id.et_child_labor_address);
        feedback=(EditText)findViewById(R.id.et_user_feedback);

        login.setOnClickListener(this);

    }

    private boolean hasCamera(){
        return getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY);
    }


    public void launchCamera(View view)
    {
        Intent intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, REQUEST_IMAGE_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == REQUEST_IMAGE_CAPTURE && resultCode==RESULT_OK)
        {
            Bundle extras = data.getExtras();
            photo = (Bitmap) extras.get("data");
            cameraImage.setImageBitmap(photo);



            File sdCardDirectory = Environment.getExternalStorageDirectory();

            File image = new File(sdCardDirectory, "test.png");
            boolean success = false;
            // Encode the file as a PNG image.
            FileOutputStream outStream;
            try {
                outStream = new FileOutputStream(image);
                photo.compress(Bitmap.CompressFormat.PNG, 100, outStream);

                outStream.flush();
                outStream.close();
                success = true;
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            catch(IOException e)
            {
                e.printStackTrace();
            }
            if (success) {
                Toast.makeText(getApplicationContext(), "Image saved with success",
                        Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(getApplicationContext(),
                        "Error during image saving", Toast.LENGTH_LONG).show();
            }
        }
    }


    @Override
    public void onClick(View v) {
        rec="wecare4u.mission@gmail.com";
        subject="Child Labor Complaint From WeCare";

        textMessage=new StringBuffer("Address is:  ");

        textMessage.append(address.getText().toString());


        textMessage.append("                                  User Feedback is: ");

        textMessage.append(feedback.getText().toString());

        textMessage.append("            Regards");

        textMessage.append("            WeCare");



        Properties props=new Properties();
        props.put("mail.smtp.host","smtp.gmail.com");
        props.put("mail.smtp.socketFactory.port","465");
        props.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");
        props.put("mail.smtp.auth","true");
        props.put("mail.smtp.port","465");

        session=Session.getDefaultInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("wecare4u.mission@gmail.com", "wecare4u");
            }
        });

        pDialog= ProgressDialog.show(context, "", "Sending Mail...", true);

        RetreiveFeedTask task=new RetreiveFeedTask();
        task.execute();

    }

    class RetreiveFeedTask extends AsyncTask<String, Void, String>
    {

        @Override
        protected String doInBackground(String... params) {

            try{
                Message message=new MimeMessage(session);
                message.setFrom(new InternetAddress("wecare4u.mission@gmail.com"));
                message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(rec));
                message.setSubject(subject);
                //   message.setContent(textMessage, "text/html; charset=utf-8");

                // Create the message part
                BodyPart messageBodyPart = new MimeBodyPart();

                // Fill the message
                messageBodyPart.setText(textMessage.toString());


                // Create a multipar message
                Multipart multipart = new MimeMultipart();

                // Set text message part
                multipart.addBodyPart(messageBodyPart);

                // Part two is attachment
                messageBodyPart = new MimeBodyPart();
                String path = Environment.getExternalStorageDirectory().toString();
                String filename = path+"/test.png";
                DataSource source = new FileDataSource(filename);
                messageBodyPart.setDataHandler(new DataHandler(source));
                messageBodyPart.setFileName(filename);
                multipart.addBodyPart(messageBodyPart);

                message.setContent(multipart );


                Transport.send(message);
            }
            catch (MessagingException e)
            {
                e.printStackTrace();
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
            return null;

        }

        @Override
        protected void onPostExecute(String result) {
            pDialog.dismiss();
            Toast.makeText(getApplicationContext(),"Message Sent... Thank You!!", Toast.LENGTH_LONG).show();


        }
    }



    @Override
    public void onBackPressed() {
        finish();
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
      }
}
